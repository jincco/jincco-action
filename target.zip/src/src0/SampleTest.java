import java.util.ArrayList;
import java.util.List;

public class SampleTest {
	private List<Integer> sink = new ArrayList<>();

	public void testSampleExecution() {

		int i = 0;      // FC
		i++;            // FC
		int j = 1;      //FC
		if (i == j) {   //PC
			sink.add(0);//FC
		} else {        //NC
			sink.add(1);//NC
		}               //NC
		sink.add(i);    //FC
		sink.add(j);    //FC
	}
}
